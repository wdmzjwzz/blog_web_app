# pre-ui

#### 介绍

pre 前端源码

#### 项目源码

|     |   后端源码  |   前端源码  |
|---  |--- | --- |
|  github   |  https://github.com/LiHaodong888/pre   |  https://github.com/LiHaodong888/pre-ui   |
|  码云   |  https://gitee.com/li_haodong/pre   |  https://gitee.com/li_haodong/pre-ui   |


#### 前端模板

初始模板基于： [https://github.com/PanJiaChen/vue-admin-template](https://github.com/PanJiaChen/vue-admin-template)

模板文档： [https://panjiachen.github.io/vue-element-admin-site/zh/guide/](https://panjiachen.github.io/vue-element-admin-site/zh/guide/)



#### 安装教程

``` bash
# 安装依赖
npm install

# 启动服务 localhost:9527
npm run dev

# 构建生产环境
npm run build
```

